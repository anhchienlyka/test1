﻿namespace FA.JustBlog.Core.Constants
{
    public static class DateTimeConstant
    {
        public const string DATE_TIME_FORMAT = "dd/MM/yyyy hh:mm:ss tt";
    }
}
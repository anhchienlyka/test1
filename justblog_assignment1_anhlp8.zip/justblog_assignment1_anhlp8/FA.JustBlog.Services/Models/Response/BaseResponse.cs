﻿using FA.JustBlog.Core.Models.Base;

namespace FA.JustBlog.Services.Models.Response
{
    public class BaseResponse : BaseEntity
    {
    }
}
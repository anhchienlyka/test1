﻿using FA.JustBlog.Core.Models;

namespace FA.JustBlog.Data.Repositories.Interfaces
{
    public interface ICategoryRepository : IGenericRepostiory<Category>
    {
        //Category Find(int categoryId);

        //void AddCategory(Category category);

        //void UpdateCategory(Category category);

        //void DeleteCategory(Category category);

        //void DeleteCategory(int categoryId);

        //IList<Category> GetAllCategories();
    }
}